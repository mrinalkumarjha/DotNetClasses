﻿using System;
using Microsoft.Practices.Unity;

namespace DependencyInjection
{
    /// <summary>
    /// Ui Layer
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {
            IUnityContainer unityContainer = new UnityContainer(); // make aware ablout classes to container
            unityContainer.RegisterType<IDal, OracleDal>("oracle");
            unityContainer.RegisterType<IDal, SqlServerDal>("sqlserver");

            // customer oracle combination
            unityContainer.RegisterType<Customer>("custorac", 
                new InjectionConstructor(
                new ResolvedParameter<IDal>("oracle")));

            // customer sqlserver combination
            unityContainer.RegisterType<Customer>("custsql",
               new InjectionConstructor(
               new ResolvedParameter<IDal>("sqlserver")));


            // Now based on key custorac, custsql we can inject any one 

            Customer obj = unityContainer.Resolve<Customer>("custorac");
            obj.CustomerName = "mrinal";
            obj.Add();

        }
    }

    /// <summary>
    /// Middle layer
    /// </summary>
    public class Customer
    {
        private readonly IDal dal;

        public string CustomerName { get; set; }

        public Customer(IDal dal)
        {
            this.dal = dal;
        }
        public void Add()
        {
            dal.Add();
        }
    }

    /// <summary>
    /// DAL LAYER
    /// </summary>
    /// 

    public interface IDal
    {
        void Add();
    }

    public class SqlServerDal: IDal
    {
        public void Add()
        {
            Console.WriteLine("adding in sql server");
        }

        public void Update()
        {
            Console.WriteLine("update in sql server");
        }

        public void Delete()
        {
            Console.WriteLine("deleting in sql server");
        }
    }

    public class OracleDal: IDal
    {
        public void Add()
        {
            Console.WriteLine("adding in sql server");
        }

        public void Update()
        {
            Console.WriteLine("update in sql server");
        }

        public void Delete()
        {
            Console.WriteLine("deleting in sql server");
        }
    }



}
