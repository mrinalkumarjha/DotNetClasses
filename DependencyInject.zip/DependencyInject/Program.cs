﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using StructureMap;

namespace DependencyInject
{
    class Program
    {
        static void Main(string[] args)
        {
            // setup container of structuremap.
            var application = Container.For<InstanceScanner>();

            var managerInstance = application.GetInstance<Manager>();

            managerInstance.ManagerWriter();


        }
    }
}
