﻿step to add structure map in project

1: Tools > Nugetpackage Manager > Manage nugetpackage for solution
2: search structuremap > install 4.4.1
3: check reference section if it is installed or not.
4: create instancescanner class
5: create manager class (this will hold all the dependency. we will add all dependencies here to inject)
6: 