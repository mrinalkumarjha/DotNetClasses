﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DependencyInject
{
    public class Manager
    {
        public ILogger _logger;

        public Manager(ILogger logger)
        {
            _logger = logger;
        }

        public void ManagerWriter()
        {
            _logger.WriteHerePlease("hello mirnal");
        }
    }
}
