﻿using StructureMap;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DependencyInject
{
    public class InstanceScanner: Registry
    {
        public InstanceScanner()
        {
            Scan(_ =>
           {
               _.TheCallingAssembly();
               _.WithDefaultConventions(); // this means if class name is logger interface should Ilogger

           });

        }
    }
}
