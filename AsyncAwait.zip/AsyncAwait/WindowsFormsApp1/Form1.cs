﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private async void button1_Click(object sender, EventArgs e)
        {
            DownloadHtmlAsync("http://msdn.microsoft.com");

            var getHtmlTask =  GetHtmlAsync("http://msdn.microsoft.com");
            MessageBox.Show("Waiting for data do download..");
            dynamic html = await getHtmlTask;

            MessageBox.Show(html.Substring(0, 10));
        }


        public string GetHtml(string sUrl)
        {
            var webClient = new WebClient();
            return webClient.DownloadString(sUrl);
        }

        public async Task<string> GetHtmlAsync(string sUrl)
        {
            var webClient = new WebClient();
            return await webClient.DownloadStringTaskAsync(sUrl);
        }

        public async Task DownloadHtmlAsync(string sUrl)
        {
            var webclient = new WebClient();
            var html = await webclient.DownloadStringTaskAsync(sUrl);
            using (var streamwriter = new StreamWriter(@"c:\test\test.html"))
            {
               await streamwriter.WriteAsync(html);
            };
        }
        public void DownloadHtml(string sUrl)
        {
            System.Threading.Thread.Sleep(5000);
            var webclient = new WebClient();
            var html = webclient.DownloadString(sUrl);
            using (var streamwriter = new StreamWriter(@"c:\test\test.html"))
            {
                streamwriter.Write(html);
            };
        }


    }
}
