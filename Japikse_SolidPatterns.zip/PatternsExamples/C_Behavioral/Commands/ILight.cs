namespace PatternsExamples.C_Behavioral.Commands
{
    public interface ILight
    {
        bool LightIsOn { get; set; }
    }
}