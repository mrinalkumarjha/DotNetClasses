﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Linq
{
    public partial class Chap_7_Projection_Operator : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            EmployeeDbContext context = new EmployeeDbContext();
            var employees = context.Employees
                .Select(emp => new { FirstName = emp.FirstName, LastNAme = emp.LastName }).ToList();

             var res = context.Employees
                .Select(emp => new { FullName = emp.FirstName + emp.LastName, MonthlySalary = emp.Salary / 12}).ToList();

             var res1 = context.Employees
                .Where(emp => emp.Salary > 5000)
               .Select(emp => new { FullName = emp.FirstName + emp.LastName, MonthlySalary = emp.Salary / 12, Bonus= emp.Salary * .1 }).ToList();


        }
    }
}