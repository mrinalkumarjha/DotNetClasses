﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Linq
{
    public partial class TwoWayToWriteLinq : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // using Lambda exp
            IEnumerable<Student1> result = Student1.GetAllStudents().Where(s => s.ID == 101);
            GridView1.DataSource = result;
            GridView1.DataBind();

            // using sql like exp
            var res = from s in Student1.GetAllStudents()
                      where s.ID == 101
                      select s;
        }
    }

    public class Student1
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public string Gender { get; set; }

        public static List<Student1> GetAllStudents()
        {
            List<Student1> listStudents = new List<Student1>();

            Student1 student1 = new Student1
            {
                ID = 101,
                Name = "Mark",
                Gender = "Male"
            };
            listStudents.Add(student1);

            Student1 student2 = new Student1
            {
                ID = 102,
                Name = "Mary",
                Gender = "Female"
            };
            listStudents.Add(student2);

            Student1 student3 = new Student1
            {
                ID = 103,
                Name = "John",
                Gender = "Male"
            };
            listStudents.Add(student3);

            Student1 student4 = new Student1
            {
                ID = 104,
                Name = "Steve",
                Gender = "Male"
            };
            listStudents.Add(student4);

            Student1 student5 = new Student1
            {
                ID = 105,
                Name = "Pam",
                Gender = "Female"
            };
            listStudents.Add(student5);

            return listStudents;
        }
    }
}