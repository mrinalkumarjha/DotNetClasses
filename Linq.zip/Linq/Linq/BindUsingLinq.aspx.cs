﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Linq
{
    public partial class BindUsingLinq : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // linq to sql
            SampleDataContext sampleDataContext = new SampleDataContext();
            var st = from student in sampleDataContext.Students
                     where student.id == 1
                     select student;
            GridView1.DataSource = st;
            GridView1.DataBind();
        }
    }
}