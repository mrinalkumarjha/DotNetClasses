﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Linq
{
    public partial class Chap_11_OrderingOperator : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            IEnumerable<Student11> result = Student11.GetAllStudetns()
                .OrderBy(s => s.TotalMarks).ThenBy(s => s.Name).ThenBy(s => s.StudentID);
            foreach (Student11 student in result)
            {
                Console.WriteLine(student.TotalMarks + "\t" + student.Name + "\t" + student.StudentID);
            }


            IEnumerable<Student11> result1 = from student in Student11.GetAllStudetns()
                                          orderby student.TotalMarks, student.Name, student.StudentID
                                          select student;
            foreach (Student11 student in result)
            {
                Console.WriteLine(student.TotalMarks + "\t" + student.Name + "\t" + student.StudentID);
            }


            // reverse list

            IEnumerable<Student11> result12 = Student11.GetAllStudetns();

            IEnumerable<Student11> rev = result12.Reverse();

        }
    }

    public class Student11
    {
        public int StudentID { get; set; }
        public string Name { get; set; }
        public int TotalMarks { get; set; }

        public static List<Student11> GetAllStudetns()
        {
            List<Student11> listStudents = new List<Student11>
        {
            new Student11
            {
                StudentID= 101,
                Name = "Tom",
                TotalMarks = 800
            },
            new Student11
            {
                StudentID= 102,
                Name = "Mary",
                TotalMarks = 900
            },
            new Student11
            {
                StudentID= 103,
                Name = "Pam",
                TotalMarks = 800
            },
            new Student11
            {
                StudentID= 104,
                Name = "John",
                TotalMarks = 800
            },
            new Student11
            {
                StudentID= 105,
                Name = "John",
                TotalMarks = 800
            },
        };

            return listStudents;
        }
    }


}