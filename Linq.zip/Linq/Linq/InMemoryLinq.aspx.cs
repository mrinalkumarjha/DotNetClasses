﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Linq
{
    public partial class InMemoryLinq : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            int[] nums = { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
            var num = from n in nums
                      where (n % 2 == 0)
                      select n;
            GridView1.DataSource = num;
            GridView1.DataBind();


            List<int> numbers = new List<int> { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
            IEnumerable<int> EvenNumbers = numbers.Where(a => a % 2 == 0);
            // wrapper style
            IEnumerable<int> evno = Enumerable.Where(numbers, b => b % 2 == 0);




            // aggregate function in linq

            // find smallest no from array using linq
            int smallno = nums.Min();
            // find smallest even no using linq
            int res = nums.Where(n=>n%2==0).Min();

            int max = nums.Max();
            int maxeven = nums.Where(n => n % 2 == 0).Max();


            // find sum of all number
            int sum = nums.Sum();

            // find sum of all even no using linq
            int allevensum = nums.Where(n => n % 2 == 0).Sum();

            // find count
            int count = nums.Count();
            int evencount = nums.Where(n => n % 2 == 0).Count();

            // find average
            double avg = nums.Average();


            string[] sArr = { "India", "USA", "UK" };
            int iMinCont = sArr.Min(s => s.Length);
            int iMaxCount = sArr.Max(s => s.Length);

            // using aggregate function .
            // example to combine string array with linq
            string sCountries = sArr.Aggregate((a, b) => a + ',' + b);

            //multiplying array with lambda exp
            int[] arr = { 1, 2, 3, 4, 5, 6 };
            int mul = arr.Aggregate((a, b) => a * b);

            // mul with seed value
            mul = arr.Aggregate(10,(a, b) => a * b);

            // how aggregate function work
            // by specifying parameter (a,b) each no is taken from array in var a, b and multiplied 
            // and put back in a var. it goes untill last index found.



        }
    }
}