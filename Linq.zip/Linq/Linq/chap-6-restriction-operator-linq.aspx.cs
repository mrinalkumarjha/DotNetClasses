﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Linq
{
    public partial class chap_6_restriction_operator_linq : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            List<int> lst = new List<int> {1,2,3,4,5,6,7,8,9 };
            // get even numbers from list
            IEnumerable<int> evennum = lst.Where(a => a % 2 == 0);
            // another way to write this

            Func<int, bool> predicate = x => x % 2 == 0;
            IEnumerable<int> evnnums = lst.Where(predicate);

            // by creating function

            IEnumerable<int> evnnums1 = lst.Where(num=> IsEven(num));

            // from tsql like
            var res = from n in lst
                      where n % 2 == 0
                      select n;

            // all even no with index position in array
            // var is used to store annomous types
            var result = lst
                .Select((num, index) => new { Number = num, Index = index })
                .Where(a => a.Number % 2 == 0);


            // querying database objects
            EmployeeDbContext context = new EmployeeDbContext();
            IEnumerable<Department> departments = context.Departments
                .Where(x => x.Name == "IT");

            foreach(Department dept in departments)
            {
                Response.Write("Dept name =" + dept.Name);
               IEnumerable<Employee> employees = dept.Employees.Where(x=>x.Gender =="Male");
                foreach(Employee employee in employees)
                {
                    Response.Write("emp name =" + employee.FirstName);
                }

            }
        }

        private static bool IsEven(int a)
        {
            return a % 2 == 0;
        }
    }
}