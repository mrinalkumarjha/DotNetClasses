﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Linq
{
    public partial class ExtensionMethod : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string s = "mrinal";
            string newval = s.ConvertCase();
        }
    }

    public static class StringHelper
    {
        public static string ConvertCase(this string s)
        {
            if(s.Length > 0)
            {
                char[] chararr = s.ToCharArray();
                chararr[0] = char.IsUpper(chararr[0]) ? char.ToLower(chararr[0]) : char.ToUpper(chararr[0]);
                return new string(chararr); 
            }
            return s;
        }
    }
}