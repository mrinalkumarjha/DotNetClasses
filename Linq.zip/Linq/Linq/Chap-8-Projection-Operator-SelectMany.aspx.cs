﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Linq
{
    public partial class Chap_8_Projection_Operator_SelectMany : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // usinf select
            var sss = Student8.GetAllStudetns().Select(s => s.Subjects);

            //using lambda
            IEnumerable<string> subjectsofallstudent = Student8.GetAllStudetns().SelectMany(s => s.Subjects);
            // to select distinct subject
            subjectsofallstudent = Student8.GetAllStudetns().SelectMany(s => s.Subjects).Distinct();

            // using sqllike syntax
            // here first from clause get data of student
            // second from clause gets data from students
            IEnumerable<string> marksusingSqlLikeSystax = from students in Student8.GetAllStudetns()
                                                          from subjects in students.Subjects
                                                          select subjects;

            // distinct using sqllike syntax.
            marksusingSqlLikeSystax = (from stu in Student8.GetAllStudetns()
                                      from sub in stu.Subjects
                                      select sub).Distinct();

            // student name with subject
            var stusub = Student8.GetAllStudetns().SelectMany(s => s.Subjects, (stu,sub)=> new {Name=stu.Name, subj = sub });
           
            var snamesub = from stu in Student8.GetAllStudetns()
            from sub in stu.Subjects
            select new { name = stu.Name, subject = sub };



            // example 3
            // print each char from string array
            string[] sarr = { "ABCDEFGH", "123456789" };
            IEnumerable<char> res = sarr.SelectMany(s => s);

            // using sql like syntax
           var ss = from s in sarr
                    from ch in s
            select ch;



            // sorting order 
             IEnumerable<Student8> res11 = Student8.GetAllStudetns().OrderBy(s=> s.Name);

             res11 = Student8.GetAllStudetns().OrderByDescending(s => s.Name);

            // using sqllike syntax :
            var res12 = from s in Student8.GetAllStudetns()
                        orderby s.Name ascending
                        select s;



        }
    }

    public class Student8
    {
        public string Name { get; set; }
        public string Gender { get; set; }
        public List<string> Subjects { get; set; }

        public static List<Student8> GetAllStudetns()
        {
            List<Student8> listStudents = new List<Student8>
        {
            new Student8
            {
                Name = "Tom",
                Gender = "Male",
                Subjects = new List<string> { "ASP.NET", "C#" }
            },
            new Student8
            {
                Name = "Mike",
                Gender = "Male",
                Subjects = new List<string> { "ADO.NET", "C#", "AJAX" }
            },
            new Student8
            {
                Name = "Pam",
                Gender = "Female",
                Subjects = new List<string> { "WCF", "SQL Server", "C#" }
            },
            new Student8
            {
                Name = "Mary",
                Gender = "Female",
                Subjects = new List<string> { "WPF", "LINQ", "ASP.NET" }
            },
        };

            return listStudents;
        }
    }
}