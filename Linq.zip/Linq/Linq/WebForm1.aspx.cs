﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Linq
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // Ado way to read data..

            //string cs = ConfigurationManager.ConnectionStrings["NewConnectionString"].ConnectionString;
            //SqlConnection sqlConnection = new SqlConnection(cs);
            //SqlCommand sqlCommand = new SqlCommand("select * from Students", sqlConnection);
            //List<Student> students = new List<Student>();
            //sqlConnection.Open();
            //SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();
            //while(sqlDataReader.Read())
            //{
            //    Student student = new Student();
            //    student.id = Convert.ToInt32(sqlDataReader["id"]);
            //    student.name = sqlDataReader["name"].ToString();
            //    student.gender = sqlDataReader["gender"].ToString();
            //    students.Add(student);
            //}
            //GridView1.DataSource = students;
            //GridView1.DataBind();
        }
    }

    //public class Student
    //{
    //    public int id { get; set; }
    //    public string name { get; set; }
    //    public string gender { get; set; }
    //}
}