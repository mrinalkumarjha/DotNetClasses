﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Linq
{
    public partial class InnerJoin : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            var result = Employee1.GetAllEmployees().Join(Department1.GetAllDepartments(), emp => emp.DepartmentID, d => d.ID,
                (emp, dept) => new {EmployeeName = emp.Name, DepartmentName = dept.Name });

            // sqllike syntax

            var res = from emp in Employee1.GetAllEmployees()
                      join d in Department1.GetAllDepartments()
                      on emp.DepartmentID equals d.ID
                      select new {EmpName = emp.Name, d.Name };
        }
    }

    public class Department1
    {
        public int ID { get; set; }
        public string Name { get; set; }

        public static List<Department1> GetAllDepartments()
        {
            return new List<Department1>()
        {
            new Department1 { ID = 1, Name = "IT"},
            new Department1 { ID = 2, Name = "HR"},
            new Department1 { ID = 3, Name = "Payroll"},
        };
        }
    }

    public class Employee1
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public int DepartmentID { get; set; }

        public static List<Employee1> GetAllEmployees()
        {
            return new List<Employee1>()
        {
            new Employee1 { ID = 1, Name = "Mark", DepartmentID = 1 },
            new Employee1 { ID = 2, Name = "Steve", DepartmentID = 2 },
            new Employee1 { ID = 3, Name = "Ben", DepartmentID = 1 },
            new Employee1 { ID = 4, Name = "Philip", DepartmentID = 1 },
            new Employee1 { ID = 5, Name = "Mary", DepartmentID = 2 },
            new Employee1 { ID = 6, Name = "Valarie", DepartmentID = 2 },
            new Employee1 { ID = 7, Name = "John", DepartmentID = 1 },
            new Employee1 { ID = 8, Name = "Pam", DepartmentID = 1 },
            new Employee1 { ID = 9, Name = "Stacey", DepartmentID = 2 },
            new Employee1 { ID = 10, Name = "Andy"}
        };
        }
    }
}