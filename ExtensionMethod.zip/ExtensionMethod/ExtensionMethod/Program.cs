﻿using System;
using CommonUtil;

namespace ExtensionMethod
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter first no:");
            int i = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter second no:");
            int j = Convert.ToInt32(Console.ReadLine());
            util outil = new util();
            Console.WriteLine(outil.add(i, j));
            Console.ReadLine();

            // adding extension method
            Console.WriteLine("Enter first no:");
            int x = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter second no:");
            int y = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine(outil.substract(x, y));
            Console.ReadLine();


        }
    }
}
