﻿using System;
using System.Collections.Generic;
using System.Text;
using CommonUtil;

namespace ExtensionMethod
{
    // 1st step make it satatic
    public static class MyClassClass
    {
        public static int substract(this util outil, int i, int j)
        {
            return i - j;
        }
    }
}
