﻿using System;

namespace CommonUtil
{
    public class util
    {
        public int add(int i, int j)
        {
            return i + j;
        }
    }
}
