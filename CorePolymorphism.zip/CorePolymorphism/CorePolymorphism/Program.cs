﻿using System;

namespace CorePolymorphism
{
    class Program
    {
        static void Main(string[] args)
        {
            Emp o = new Emp();

            // static polymorphism.. // early binding // function overloading // compile time polymorphism
            int j = o.calculatesalary();
            int i = o.calculatesalary(10);


            // run time polymorphism // late binding // function overriding
            PartTimeEmp oPartTimeEmp = new PartTimeEmp();
            int x =  oPartTimeEmp.calculatesalary();
            int y = oPartTimeEmp.calculatesalary(20);

        }
    }

    public class Emp
    {
        public int calculatesalary()
        {
            return 100;
        }

        public int calculatesalary(int month)
        {
            return 100 * month;
        }

    }

    public class PartTimeEmp:Emp
    {
        public int calculatesalary()
        {
            return 50;
        }
    }



}
